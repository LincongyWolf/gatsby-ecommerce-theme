// A anon key é pública por design; quem protege os dados são as regras (RLS) do schema.sql.
// NUNCA coloque aqui a service_role key nem senhas.
window.CONFIG = {
  SUPABASE_URL: 'COLE_AQUI_A_URL_DO_PROJETO',
  SUPABASE_ANON_KEY: 'COLE_AQUI_A_ANON_KEY'
};
