const C = window.CONFIG;
const sb = C.SUPABASE_URL && !C.SUPABASE_URL.startsWith('COLE') ? supabase.createClient(C.SUPABASE_URL, C.SUPABASE_ANON_KEY) : null;
const $ = s => document.querySelector(s);
const GROUPS = [['Ação e Aventura','acao'],['Comédias','comedia'],['Ficção Científica','ficcao'],['Séries Clássicas','serie']];
let titles = [], user = null, isAdmin = false, mine = new Set();
const hue = s => [...s].reduce((a, c) => a + c.charCodeAt(0), 0) % 360;

async function load() {
  if (sb) {
    const { data, error } = await sb.from('titles').select('*').order('year');
    if (!error && data.length) { titles = data; return; }
  }
  titles = await (await fetch('catalog.json')).json(); // modo sem banco
}

function card(t) {
  const c = document.createElement('div');
  c.className = 'card';
  const h = hue(t.title);
  c.style.background = `linear-gradient(135deg,hsl(${h} 50% 28%),hsl(${(h + 50) % 360} 55% 13%))`;
  if (/^https?:\/\//.test(t.poster || '')) {
    const im = new Image(); im.src = t.poster; im.alt = t.title; im.loading = 'lazy'; c.appendChild(im);
  }
  const s = document.createElement('span'); s.textContent = t.title;
  const m = document.createElement('small'); m.textContent = t.year || ''; s.appendChild(m); c.appendChild(s);
  if (sb && user && t.id) {
    const b = document.createElement('button'); b.className = 'hb' + (mine.has(t.id) ? ' on' : '');
    b.textContent = mine.has(t.id) ? '♥' : '♡'; b.title = 'Minha Lista';
    b.onclick = e => { e.stopPropagation(); toggle(t); }; c.appendChild(b);
  }
  if (isAdmin && t.id) {
    const d = document.createElement('button'); d.className = 'hb'; d.style.right = '42px'; d.textContent = '×'; d.title = 'Remover';
    d.onclick = e => { e.stopPropagation(); del(t); }; c.appendChild(d);
  }
  c.onclick = () => play(t);
  return c;
}

function render() {
  const q = $('#q').value.toLowerCase(), R = $('#rows'); R.replaceChildren();
  const lists = [];
  if (user && mine.size) lists.push(['Minha Lista', titles.filter(t => mine.has(t.id))]);
  GROUPS.forEach(([n, g]) => lists.push([n, titles.filter(t => t.genre === g)]));
  lists.forEach(([n, l]) => {
    l = l.filter(t => t.title.toLowerCase().includes(q)); if (!l.length) return;
    const s = document.createElement('section'), h = document.createElement('h2'), row = document.createElement('div');
    h.textContent = n; row.className = 'row'; l.forEach(t => row.appendChild(card(t))); s.append(h, row); R.appendChild(s);
  });
}

function play(t) {
  const v = t.video || '', d = $('#dlg-play'), vid = $('#vid');
  $('#play-title').textContent = t.title;
  if (/^https?:\/\//.test(v)) {
    if (/\.m3u8(\?|$)/.test(v)) {
      if (window.Hls && Hls.isSupported()) { const h = new Hls(); h.loadSource(v); h.attachMedia(vid); d._h = h; } else vid.src = v;
    } else if (/\.(mp4|webm)(\?|$)/.test(v)) vid.src = v;
    else { window.open(v, '_blank', 'noopener'); return; }
    d.showModal(); vid.play().catch(() => {});
  } else window.open('https://archive.org/search?query=' + encodeURIComponent(t.title) + '&and[]=mediatype%3A%22movies%22', '_blank', 'noopener');
}
$('#dlg-play').addEventListener('close', () => {
  const d = $('#dlg-play'), vid = $('#vid'); vid.pause(); vid.removeAttribute('src');
  if (d._h) { d._h.destroy(); d._h = null; }
});

async function toggle(t) {
  if (mine.has(t.id)) { await sb.from('my_list').delete().eq('title_id', t.id); mine.delete(t.id); }
  else { await sb.from('my_list').insert({ title_id: t.id }); mine.add(t.id); }
  render();
}
async function del(t) {
  if (!confirm('Remover "' + t.title + '"?')) return;
  const { error } = await sb.from('titles').delete().eq('id', t.id);
  if (error) return alert(error.message);
  await load(); render();
}
$('#f-add').onsubmit = async e => {
  e.preventDefault();
  const v = Object.fromEntries(new FormData(e.target));
  v.year = v.year ? +v.year : null;
  ['poster', 'video', 'license'].forEach(k => { if (!v[k]) v[k] = null; });
  const { error } = await sb.from('titles').insert(v); // o servidor só aceita se você for admin (RLS)
  if (error) return alert(error.message);
  e.target.reset(); await load(); render();
};

async function refreshUser() {
  if (!sb) return;
  const { data } = await sb.auth.getSession();
  user = data.session ? data.session.user : null; isAdmin = false; mine = new Set();
  if (user) {
    const [p, m] = await Promise.all([sb.from('profiles').select('role').eq('id', user.id).maybeSingle(), sb.from('my_list').select('title_id')]);
    isAdmin = !!(p.data && p.data.role === 'admin');
    (m.data || []).forEach(r => mine.add(r.title_id));
  }
  $('#auth-btn').textContent = user ? 'SAIR' : 'ENTRAR';
  $('#admin').hidden = !isAdmin; render();
}
$('#auth-btn').onclick = async () => {
  if (!sb) return alert('Configure js/config.js com os dados do Supabase (veja o README).');
  if (user) { await sb.auth.signOut(); refreshUser(); } else $('#dlg-auth').showModal();
};
async function doAuth(signup) {
  const email = $('#em').value.trim(), password = $('#pw').value, msg = $('#amsg'); msg.textContent = '';
  if (!sb) { msg.textContent = 'Supabase não configurado.'; return; }
  const r = signup ? await sb.auth.signUp({ email, password }) : await sb.auth.signInWithPassword({ email, password });
  if (r.error) { msg.textContent = r.error.message; return; }
  if (signup && !r.data.session) { msg.textContent = 'Conta criada. Confirme o e-mail e depois entre.'; return; }
  $('#dlg-auth').close(); refreshUser();
}
$('#b-in').onclick = () => doAuth(false); $('#b-up').onclick = () => doAuth(true);
$('#q').oninput = render;
load().then(() => { render(); refreshUser(); });
