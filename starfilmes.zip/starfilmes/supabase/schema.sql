-- Rode este arquivo no SQL Editor do Supabase.
create table public.profiles (
  id uuid primary key references auth.users on delete cascade,
  role text not null default 'user' check (role in ('user','admin'))
);
create table public.titles (
  id bigint generated always as identity primary key,
  title text not null,
  year int,
  genre text not null check (genre in ('acao','comedia','ficcao','serie')),
  license text,
  poster text,
  video text,
  created_at timestamptz not null default now()
);
create table public.my_list (
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  title_id bigint not null references public.titles on delete cascade,
  primary key (user_id, title_id)
);
alter table public.profiles enable row level security;
alter table public.titles enable row level security;
alter table public.my_list enable row level security;

create function public.is_admin() returns boolean
language sql security definer set search_path = public stable
as $$ select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin') $$;

create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public
as $$ begin insert into public.profiles (id) values (new.id); return new; end $$;
create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

create policy "titulos: todos leem" on public.titles for select to anon, authenticated using (true);
create policy "titulos: admin insere" on public.titles for insert to authenticated with check (public.is_admin());
create policy "titulos: admin edita" on public.titles for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "titulos: admin remove" on public.titles for delete to authenticated using (public.is_admin());
create policy "perfil: cada um le o seu" on public.profiles for select to authenticated using (id = auth.uid());
create policy "lista: so o dono" on public.my_list for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
